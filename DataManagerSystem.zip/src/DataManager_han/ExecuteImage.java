package DataManager_han;

import java.awt.*;
import javax.swing.*;

public class ExecuteImage extends JFrame{

	Container contentPane;

	ExecuteImage(String s){
		setTitle(s);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.setBackground(Color.WHITE);


		ImageIcon icon = new ImageIcon(DirectoryList.filePath + s);  
		//Image img = icon.getImage();
		JLabel imageLabel = new JLabel(icon);


		//int x = icon.getIconWidth();
		//int y = icon.getIconHeight();


		contentPane.add(imageLabel,BorderLayout.CENTER);
		setSize(350,400);
		setVisible(true);

	}

}


