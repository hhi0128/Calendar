package DataManager_han;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import javazoom.jl.player.advanced.AdvancedPlayer;
import javazoom.jl.player.advanced.PlaybackEvent;
import javazoom.jl.player.advanced.PlaybackListener;

class StartMusic extends Thread{
	
	public AdvancedPlayer player;
	
	private boolean isLoop;
	public static int pausedOnFrame = 0;
	
	private File file;
	private FileInputStream fileInputStream;
	private BufferedInputStream bufferedInputStream;
	
	public StartMusic(File file, boolean isLoop) {
		try{
			this.isLoop = isLoop;
			this.file = file;
			fileInputStream = new FileInputStream(file);
			bufferedInputStream = new BufferedInputStream(fileInputStream);
			player = new AdvancedPlayer(bufferedInputStream);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		isLoop = false;
		player.setPlayBackListener(new PlaybackListener() {
			public void playbackFinished(PlaybackEvent event) {
				pausedOnFrame = event.getFrame();
			}
		});
		player.stop();
		this.interrupt();
	}
	
	@Override
	public void run() {
		try {
			do {
				player.play(pausedOnFrame / 26, Integer.MAX_VALUE);
				fileInputStream = new FileInputStream(file);
				bufferedInputStream = new BufferedInputStream(fileInputStream);
				player = new AdvancedPlayer(bufferedInputStream);
			}while(isLoop);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

public class ExecuteMusic extends JFrame{
	
	
	private ImageIcon startButtonIcon = new ImageIcon("./images/startIcon.png");
	private ImageIcon pauseButtonIcon = new ImageIcon("./images/pauseIcon.png");
	private ImageIcon stopButtonIcon = new ImageIcon("./images/stopIcon.png");
	
	private JButton startButton;
	private JButton pauseButton;
	private JButton stopButton;

	StartMusic music;
	
	Container contentPane;

	ExecuteMusic(String s){
		setTitle(s);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout());
		contentPane.setBackground(Color.WHITE);

		startButton = new JButton(startButtonIcon);
		pauseButton = new JButton(pauseButtonIcon);
		stopButton = new JButton(stopButtonIcon);

		File file  = new File(DirectoryList.filePath + s);

		music = new StartMusic(file, true);
					
		startButton.setBackground(Color.WHITE);
		pauseButton.setBackground(Color.WHITE);
		stopButton.setBackground(Color.WHITE);
		
		startButton.setBorder(null);
		pauseButton.setBorder(null);
		stopButton.setBorder(null);
		
		contentPane.add(startButton);
		contentPane.add(pauseButton);
		contentPane.add(stopButton);
		
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				music = new StartMusic(file, true);
				music.start();
				
			}});
		
		pauseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				music.close();
				
			}});
		
		stopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				music.close();
				music.pausedOnFrame = 0;

			}});
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				music.close();
			}
		});

		setSize(300,130);
		setLocationRelativeTo(null);
		setVisible(true);

	}

}
