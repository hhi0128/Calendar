package DataManager_han;
/*
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class FileWrite{

	FileWrite(){
		try {
			String outputString = "./hello.txt";
			FileWriter output = new FileWriter(outputString);

			for(int i = 0 ; i < 11 ; i++) {
				String data = i + "��° ���Դϴ�.\r\n";
				output.write(data);
			}
			output.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}*/