package DataManager_han;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;

//버튼별 기능 구현
public class FileButton extends JPanel{

	// 이미지
	private ImageIcon loadImageIcon = new ImageIcon("./images/importIcon.png");
	private ImageIcon deleteImageIcon = new ImageIcon("./images/deleteIcon.png");
	private ImageIcon backImageIcon = new ImageIcon("./images/backIcon.png");
	// 이미지 버튼 생성
	public JButton fileLoadButton = new JButton(loadImageIcon);
	public JButton fileDeleteButton = new JButton(deleteImageIcon);
	public JButton backButton = new JButton(backImageIcon);

	
	public FileButton(){

		// FlowLayout으로 버튼 배치
		setLayout(new FlowLayout());
		// Background 컬러
		setBackground(Color.WHITE);

		// 버튼내 컬러
		fileLoadButton.setBackground(Color.WHITE);
		fileDeleteButton.setBackground(Color.WHITE);
		backButton.setBackground(Color.WHITE);

		// 버튼 내 레이아웃을 보더레이아웃으로.
		fileLoadButton.setBorder(null);
		fileDeleteButton.setBorder(null);
		backButton.setBorder(null);

		//액션리스너 부착
		fileLoadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				new FileChooser();


			}
		});
		
		//home 디텍토리가 아닐 시 상위 디텍토리로 이동
		backButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String name = DirectoryList.filePath;
						
					if(name.length() > ".\\home\\".length()) {
						Home.homePanel.removeAll();

						File f2 = new File(DirectoryList.filePath);	

						String fname = f2.getParent();
						DirectoryList.filePath=fname+"\\";

						Home.setHome();

						Home.homePanel.repaint();
						Home.homePanel.revalidate();

						System.out.println(DirectoryList.filePath);						
					}

			}
		});

	
		add(fileLoadButton);
		add(fileDeleteButton);
		add(backButton);

	}


}
