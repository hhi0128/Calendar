package DataManager_han;

import java.awt.*;
import javax.swing.*;

public class Music extends JPanel{

	public JPanel musicPanel = new JPanel();
	
	public Music(){
		
		setLayout(new BorderLayout());
		
		musicPanel.setBackground(Color.WHITE);
		
		add(new FileButton(), BorderLayout.EAST);
		add(musicPanel, BorderLayout.CENTER);		
		
		//musicPanel
	}

}
