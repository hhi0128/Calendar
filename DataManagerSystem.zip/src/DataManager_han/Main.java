package DataManager_han;

public class Main {
	
	public static final int Main_Width = 800;
	public static final int Main_Height = 600;
	
	public static void main(String[] args) {
		
		new SaveData();
	
	}

}


