package DataManager_han;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;
import javax.swing.border.*;

public class Home extends JPanel {

	// Ȩ�г� ����
	public static JPanel homePanel = new JPanel();
	public static JPanel folderPanel[] = new JPanel[20];
	// ���� ������ ����
	public static ImageIcon folderIcon = new ImageIcon(".\\images\\folderIcon.png");

	// home �����丮�� ���� ��ư ����
	public static JButton homeDirectoryButton[];
	public static String fileName;

	// DirectoryList ����
	static DirectoryList directoryList = new DirectoryList();

	public Home() {

		setLayout(new BorderLayout());

		homePanel.setLayout(new GridLayout(3, 6));
		add(new Search(), BorderLayout.SOUTH);
		homePanel.setBackground(Color.WHITE);

		homeDirectoryButton = new JButton[directoryList.directoryNum];
		// home �����丮�� ����Ʈ ������ŭ ��ư�� ����

		setHome(); // ���� ���� ĸ��ȭ

		// ���� ��ư ���� , Ȩ �г� ����
		add(new FileButton(), BorderLayout.EAST);
		add(homePanel, BorderLayout.CENTER);
	}

	public static void setHome() {

		directoryList = new DirectoryList();
		homeDirectoryButton = new JButton[directoryList.directoryNum];

		for (int i = 0; i < folderPanel.length; i++) {
			folderPanel[i] = new JPanel();
			folderPanel[i].setBackground(Color.WHITE);
			homePanel.add(folderPanel[i]);

		}

		for (int i = 0; i < directoryList.directoryNum; i++) {
			homeDirectoryButton[i] = new JButton(folderIcon);

			// ���� �����丮 ����Ʈ ������� �̸� �ο�.
			fileName = directoryList.list[i];

			if (fileName.substring(fileName.length() - 3).equals("txt")) {
				homeDirectoryButton[i].setIcon(SaveData.textFileIcon);
			}

			else if (fileName.substring(fileName.length() - 3).equals("png")) {
				ImageIcon tmp = new ImageIcon(DirectoryList.filePath + "\\" + fileName);
				java.awt.Image origin = tmp.getImage();
				java.awt.Image change = origin.getScaledInstance(75, 75, Image.UNDEFINED_CONDITION);
				ImageIcon result = new ImageIcon(change);
				homeDirectoryButton[i].setIcon(result);

			}

			else if (fileName.substring(fileName.length() - 3).equals("mp3")) {
				homeDirectoryButton[i].setIcon(SaveData.musicFileIcon);
				// musicPanel.add();
			}

			TitledBorder titledBorder = new TitledBorder(directoryList.list[i]);
			titledBorder.setTitlePosition(TitledBorder.BELOW_BOTTOM);
			titledBorder.setTitleJustification(TitledBorder.CENTER);

			homeDirectoryButton[i].setBorder(titledBorder);
			homeDirectoryButton[i].setBackground(Color.WHITE);
			homeDirectoryButton[i].setActionCommand(fileName);

			// �� ��ư�� �׼Ǹ����� ����
			homeDirectoryButton[i].addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent e) {
					JButton btn = (JButton) e.getSource();
					String s = btn.getActionCommand();

					File f = new File(DirectoryList.filePath + s);

					// ������ ������ ������ ��� �ش� ������ ���� �����丮��.
					if (e.getClickCount() == 2 && f.isDirectory()) {
						System.out.println(DirectoryList.filePath);

						// DirectoryList.BeforefilePath=DirectoryList.filePath;
						DirectoryList.filePath = DirectoryList.filePath + s + "\\";

						System.out.println(DirectoryList.filePath);

						Home.homePanel.removeAll();

						Home.setHome();

					}

				}
			});

			folderPanel[i].add(homeDirectoryButton[i]);

			homeDirectoryButton[i].addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent e) {
					JButton btn = (JButton) e.getSource();
					String s = btn.getActionCommand();

					if (e.getClickCount() == 2) {
						if (s.substring(s.length() - 3).equals("txt"))
							new ExecuteText(s);

						else if (s.substring(s.length() - 3).equals("png"))
							new ExecuteImage(s);

						else if (s.substring(s.length() - 3).equals("mp3"))
							new ExecuteMusic(s);
					}
				}
			});

		}

	}

}
