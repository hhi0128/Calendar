package DataManager_han;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;

public class Search extends JPanel{

	public JLabel finding=new JLabel("find");
	private ImageIcon searchImageIcon = new ImageIcon("./images/search1.png");
	public JButton searchButton = new JButton(searchImageIcon);
	public static JTextField SField=new JTextField(10);

	public Search(){
		setLayout(new FlowLayout());
		setBackground(Color.WHITE);


		searchButton.setBackground(Color.WHITE);
		

		searchButton.setBorder(null);


		String contents = SField.getText();

		searchButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {

				SearchFolder.SearchFolder(DirectoryList.HomeDirectory , SField.getText()); 
				String Sh [] = {".txt",".png",".mp3"};
				String H[] = {"folder01/","folder02/","folder03/"};

				System.out.println("A");

				for(int i=0; i<3; i++) {
					int ff=0;
					for(int j=0; j<3; j++) {
						String makeFile  = ".\\home\\"+ H[i] + SField.getText() + Sh[j] ;
						if(fileIsLive(makeFile)) {
							if(Sh[j].equals(".txt")) {
								String name1 = SField.getText()+Sh[0];
								String s = name1;
								new ExecuteText(s);
							}
							else if(Sh[j].equals(".png")) {
								System.out.println(Sh[1]);
								String name2 = SField.getText()+Sh[1];
								String s = name2;
								System.out.println(s);
								new ExecuteImage(s);
							}
							else if(Sh[j].equals(".mp3")) {
								String s = SField.getText()+Sh[2];
								new ExecuteMusic(s);

							}
							ff=1; break;
						}
						//else
						//System.out.println("����.");
					}
					if(ff==1) break;
				}
			}

		});


		add(finding);
		add(SField);
		add(searchButton);

	}
	public static Boolean fileIsLive(String isLivefile) {
		File f1 = new File(isLivefile);

		if(f1.exists()){
			return true;
		}else{
			return false;
		}
	}

}