package DataManager_han;

import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextArea;


import javax.swing.*;
import java.io.*;

public class ExecuteText extends JFrame {

	Container contentPane;

	ImageIcon saveButtonIcon = new ImageIcon("./images/saveIcon.png");

	JTextArea ta = new JTextArea(25, 34);
	JScrollPane scrollPane = new JScrollPane(ta);

	char[] ch;
	String txt;

	JButton saveButton = new JButton(saveButtonIcon);

	ExecuteText(String s) {
		
		setTitle(s);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout());
		contentPane.setBackground(Color.WHITE);
		
		saveButton.setBorder(null);
		saveButton.setBackground(Color.WHITE);
		
		File file = new File(DirectoryList.filePath + s);

		ch = new char[(int) file.length()];

		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt = ta.getText();

				try {
					BufferedWriter fw = new BufferedWriter(new FileWriter(file, false));

					fw.write(txt);
					fw.flush();

					fw.close();

				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}
		});



		try {
			BufferedReader memoReader = new BufferedReader(new FileReader(file));
			try {
				memoReader.read(ch);

				memoReader.close();
			} catch (IOException e) {

				e.printStackTrace();
			}

		} catch (FileNotFoundException e1) {

			e1.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}

		String s1 = new String(ch);

		ta.setText(s1);

		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		contentPane.add(scrollPane);
		contentPane.add(saveButton);
	

		setSize(400, 500);
		setVisible(true);

	}
}
